DOWNLOADS
=========

# Binary Releases and Source Snapshot

As a convenience, we publish here the most recent version of the binary releases (SDK with header files, libraries and command line applications) for the most common platforms, and the corresponding source snapshot.

## Version 1.6.0-638

:fontawesome-brands-windows: &nbsp; [Binaries for Windows 10](https://www.bok.net/Bento4/binaries/Bento4-SDK-1-6-0-638.x86_64-microsoft-win32.zip)  
:fontawesome-brands-apple: &nbsp; [Binaries for macOS](https://www.bok.net/Bento4/binaries/Bento4-SDK-1-6-0-638.universal-apple-macosx.zip)  
:fontawesome-brands-linux: &nbsp; [Binaries for Linux x86_64](https://www.bok.net/Bento4/binaries/Bento4-SDK-1-6-0-638.x86_64-unknown-linux.zip)  
:fontawesome-solid-code: &nbsp; [Source Snapshot (all platforms)](https://www.bok.net/Bento4/source/Bento4-SRC-1-6-0-638.zip)  
