# mp4info
```
MP4 File Info - Version 1.3.4
(Bento4 Version 1.6.0.0)
(c) 2002-2017 Axiomatic Systems, LLC

usage: mp4info [options] <input>
Options:
  --verbose:          show extended information when available
  --format <format>:  display the information in this format.
                      <format> is: text (default) or json
  --show-layout:      show sample layout
  --show-samples:     show sample details
  --show-sample-data: show sample data
  --fast:             skip some details that are slow to compute
```
