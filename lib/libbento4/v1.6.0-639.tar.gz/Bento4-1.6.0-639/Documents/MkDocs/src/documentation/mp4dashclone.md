# mp4dashclone
```
Usage: mp4-dash-clone.py [options] <file-or-http-url> <output-dir>


Options:
  -h, --help            show this help message and exit
  --quiet               Be quiet
  --encrypt=<KID:KEY>   Encrypt the media, with KID and KEY specified in Hex
                        (32 characters each)
  --exec-dir=<exec_dir>
                        Directory where the Bento4 executables are located
```
