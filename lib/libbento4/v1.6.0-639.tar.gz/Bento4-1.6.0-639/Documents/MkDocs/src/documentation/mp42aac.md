# mp42aac
```
MP4 To AAC File Converter - Version 1.0
(Bento4 Version 1.6.0.0)
(c) 2002-2008 Axiomatic Systems, LLC

usage: mp42aac [options] <input> <output>
  Options:
  --key <hex>: 128-bit decryption key (in hex: 32 chars)
```
